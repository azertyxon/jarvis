document.getElementById("searchBar").addEventListener("input", function() {
    const query = this.value.toLowerCase();
    const resultsDiv = document.getElementById("results");
    resultsDiv.innerHTML = query ? "Recherche en cours pour: " + query : "";
});